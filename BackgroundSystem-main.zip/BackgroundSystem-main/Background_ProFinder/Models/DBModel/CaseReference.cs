﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Background_ProFinder.Models.DBModel
{
    public partial class CaseReference
    {
        public int CaseId { get; set; }
        public string CaseRefImg { get; set; }
    }
}
