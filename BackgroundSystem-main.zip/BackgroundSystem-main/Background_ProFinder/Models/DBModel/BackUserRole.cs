﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Background_ProFinder.Models.DBModel
{
    public partial class BackUserRole
    {
        public string UserId { get; set; }
        public string RoleId { get; set; }
    }
}
