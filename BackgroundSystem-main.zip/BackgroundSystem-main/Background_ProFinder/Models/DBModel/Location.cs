﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Background_ProFinder.Models.DBModel
{
    public partial class Location
    {
        public int LocationId { get; set; }
        public string LocationName { get; set; }
    }
}
